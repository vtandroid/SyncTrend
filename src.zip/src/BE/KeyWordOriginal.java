package BE;

import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.geo.GeoPoint;
import com.backendless.persistence.BackendlessDataQuery;

public class KeyWordOriginal
{
  private Integer status;
  private String key;
  private java.util.Date updated;
  private String ownerId;
  private String description;
  private java.util.Date created;
  private String objectId;
  public Integer getStatus()
  {
    return status;
  }

  public void setStatus( Integer status )
  {
    this.status = status;
  }

  public String getKey()
  {
    return key;
  }

  public void setKey( String key )
  {
    this.key = key;
  }

  public java.util.Date getUpdated()
  {
    return updated;
  }

  public String getOwnerId()
  {
    return ownerId;
  }

  public String getDescription()
  {
    return description;
  }

  public void setDescription( String description )
  {
    this.description = description;
  }

  public java.util.Date getCreated()
  {
    return created;
  }

  public String getObjectId()
  {
    return objectId;
  }

                                                    
  public KeyWordOriginal save()
  {
    return Backendless.Data.of( KeyWordOriginal.class ).save( this );
  }

  public Future<KeyWordOriginal> saveAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginal> future = new Future<KeyWordOriginal>();
      Backendless.Data.of( KeyWordOriginal.class ).save( this, future );

      return future;
    }
  }

  public void saveAsync( AsyncCallback<KeyWordOriginal> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).save( this, callback );
  }

  public Long remove()
  {
    return Backendless.Data.of( KeyWordOriginal.class ).remove( this );
  }

  public Future<Long> removeAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<Long> future = new Future<Long>();
      Backendless.Data.of( KeyWordOriginal.class ).remove( this, future );

      return future;
    }
  }

  public void removeAsync( AsyncCallback<Long> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).remove( this, callback );
  }

  public static KeyWordOriginal findById( String id )
  {
    return Backendless.Data.of( KeyWordOriginal.class ).findById( id );
  }

  public static Future<KeyWordOriginal> findByIdAsync( String id )
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginal> future = new Future<KeyWordOriginal>();
      Backendless.Data.of( KeyWordOriginal.class ).findById( id, future );

      return future;
    }
  }

  public static void findByIdAsync( String id, AsyncCallback<KeyWordOriginal> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).findById( id, callback );
  }

  public static KeyWordOriginal findFirst()
  {
    return Backendless.Data.of( KeyWordOriginal.class ).findFirst();
  }

  public static Future<KeyWordOriginal> findFirstAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginal> future = new Future<KeyWordOriginal>();
      Backendless.Data.of( KeyWordOriginal.class ).findFirst( future );

      return future;
    }
  }

  public static void findFirstAsync( AsyncCallback<KeyWordOriginal> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).findFirst( callback );
  }

  public static KeyWordOriginal findLast()
  {
    return Backendless.Data.of( KeyWordOriginal.class ).findLast();
  }

  public static Future<KeyWordOriginal> findLastAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginal> future = new Future<KeyWordOriginal>();
      Backendless.Data.of( KeyWordOriginal.class ).findLast( future );

      return future;
    }
  }

  public static void findLastAsync( AsyncCallback<KeyWordOriginal> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).findLast( callback );
  }

  public static BackendlessCollection<KeyWordOriginal> find( BackendlessDataQuery query )
  {
    return Backendless.Data.of( KeyWordOriginal.class ).find( query );
  }

  public static Future<BackendlessCollection<KeyWordOriginal>> findAsync( BackendlessDataQuery query )
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<BackendlessCollection<KeyWordOriginal>> future = new Future<BackendlessCollection<KeyWordOriginal>>();
      Backendless.Data.of( KeyWordOriginal.class ).find( query, future );

      return future;
    }
  }

  public static void findAsync( BackendlessDataQuery query, AsyncCallback<BackendlessCollection<KeyWordOriginal>> callback )
  {
    Backendless.Data.of( KeyWordOriginal.class ).find( query, callback );
  }
}