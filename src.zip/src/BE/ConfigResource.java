package BE;

import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.geo.GeoPoint;
import com.backendless.persistence.BackendlessDataQuery;

public class ConfigResource {

    private String ownerId;
    private java.util.Date created;
    private String objectId;
    private String value;
    private String key;
    private String description;
    private java.util.Date updated;

    public String getOwnerId() {
        return ownerId;
    }

    public java.util.Date getCreated() {
        return created;
    }

    public String getObjectId() {
        return objectId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public java.util.Date getUpdated() {
        return updated;
    }

    public ConfigResource save() {
        return Backendless.Data.of(ConfigResource.class).save(this);
    }

    public Future<ConfigResource> saveAsync() {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<ConfigResource> future = new Future<ConfigResource>();
            Backendless.Data.of(ConfigResource.class).save(this, future);

            return future;
        }
    }

    public void saveAsync(AsyncCallback<ConfigResource> callback) {
        Backendless.Data.of(ConfigResource.class).save(this, callback);
    }

    public Long remove() {
        return Backendless.Data.of(ConfigResource.class).remove(this);
    }

    public Future<Long> removeAsync() {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<Long> future = new Future<Long>();
            Backendless.Data.of(ConfigResource.class).remove(this, future);

            return future;
        }
    }

    public void removeAsync(AsyncCallback<Long> callback) {
        Backendless.Data.of(ConfigResource.class).remove(this, callback);
    }

    public static ConfigResource findById(String id) {
        return Backendless.Data.of(ConfigResource.class).findById(id);
    }

    public static Future<ConfigResource> findByIdAsync(String id) {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<ConfigResource> future = new Future<ConfigResource>();
            Backendless.Data.of(ConfigResource.class).findById(id, future);

            return future;
        }
    }

    public static void findByIdAsync(String id, AsyncCallback<ConfigResource> callback) {
        Backendless.Data.of(ConfigResource.class).findById(id, callback);
    }

    public static ConfigResource findFirst() {
        return Backendless.Data.of(ConfigResource.class).findFirst();
    }

    public static Future<ConfigResource> findFirstAsync() {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<ConfigResource> future = new Future<ConfigResource>();
            Backendless.Data.of(ConfigResource.class).findFirst(future);

            return future;
        }
    }

    public static void findFirstAsync(AsyncCallback<ConfigResource> callback) {
        Backendless.Data.of(ConfigResource.class).findFirst(callback);
    }

    public static ConfigResource findLast() {
        return Backendless.Data.of(ConfigResource.class).findLast();
    }

    public static Future<ConfigResource> findLastAsync() {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<ConfigResource> future = new Future<ConfigResource>();
            Backendless.Data.of(ConfigResource.class).findLast(future);

            return future;
        }
    }

    public static void findLastAsync(AsyncCallback<ConfigResource> callback) {
        Backendless.Data.of(ConfigResource.class).findLast(callback);
    }

    public static BackendlessCollection<ConfigResource> find(BackendlessDataQuery query) {
        return Backendless.Data.of(ConfigResource.class).find(query);
    }

    public static Future<BackendlessCollection<ConfigResource>> findAsync(BackendlessDataQuery query) {
        if (Backendless.isAndroid()) {
            throw new UnsupportedOperationException("Using this method is restricted in Android");
        } else {
            Future<BackendlessCollection<ConfigResource>> future = new Future<BackendlessCollection<ConfigResource>>();
            Backendless.Data.of(ConfigResource.class).find(query, future);

            return future;
        }
    }

    public static void findAsync(BackendlessDataQuery query, AsyncCallback<BackendlessCollection<ConfigResource>> callback) {
        Backendless.Data.of(ConfigResource.class).find(query, callback);
    }
}
