package BE;

import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.geo.GeoPoint;
import com.backendless.persistence.BackendlessDataQuery;

public class KeyWordOriginalBK
{
  private Integer status;
  private String key;
  private java.util.Date updated;
  private String ownerId;
  private String description;
  private java.util.Date created;
  private String objectId;
  public Integer getStatus()
  {
    return status;
  }

  public void setStatus( Integer status )
  {
    this.status = status;
  }

  public String getKey()
  {
    return key;
  }

  public void setKey( String key )
  {
    this.key = key;
  }

  public java.util.Date getUpdated()
  {
    return updated;
  }

  public String getOwnerId()
  {
    return ownerId;
  }

  public String getDescription()
  {
    return description;
  }

  public void setDescription( String description )
  {
    this.description = description;
  }

  public java.util.Date getCreated()
  {
    return created;
  }

  public String getObjectId()
  {
    return objectId;
  }

                                                    
  public KeyWordOriginalBK save()
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).save( this );
  }

  public Future<KeyWordOriginalBK> saveAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginalBK> future = new Future<KeyWordOriginalBK>();
      Backendless.Data.of(KeyWordOriginalBK.class ).save( this, future );

      return future;
    }
  }

  public void saveAsync( AsyncCallback<KeyWordOriginalBK> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).save( this, callback );
  }

  public Long remove()
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).remove( this );
  }

  public Future<Long> removeAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<Long> future = new Future<Long>();
      Backendless.Data.of(KeyWordOriginalBK.class ).remove( this, future );

      return future;
    }
  }

  public void removeAsync( AsyncCallback<Long> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).remove( this, callback );
  }

  public static KeyWordOriginalBK findById( String id )
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).findById( id );
  }

  public static Future<KeyWordOriginalBK> findByIdAsync( String id )
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginalBK> future = new Future<KeyWordOriginalBK>();
      Backendless.Data.of(KeyWordOriginalBK.class ).findById( id, future );

      return future;
    }
  }

  public static void findByIdAsync( String id, AsyncCallback<KeyWordOriginalBK> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).findById( id, callback );
  }

  public static KeyWordOriginalBK findFirst()
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).findFirst();
  }

  public static Future<KeyWordOriginalBK> findFirstAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginalBK> future = new Future<KeyWordOriginalBK>();
      Backendless.Data.of(KeyWordOriginalBK.class ).findFirst( future );

      return future;
    }
  }

  public static void findFirstAsync( AsyncCallback<KeyWordOriginalBK> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).findFirst( callback );
  }

  public static KeyWordOriginalBK findLast()
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).findLast();
  }

  public static Future<KeyWordOriginalBK> findLastAsync()
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<KeyWordOriginalBK> future = new Future<KeyWordOriginalBK>();
      Backendless.Data.of(KeyWordOriginalBK.class ).findLast( future );

      return future;
    }
  }

  public static void findLastAsync( AsyncCallback<KeyWordOriginalBK> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).findLast( callback );
  }

  public static BackendlessCollection<KeyWordOriginalBK> find( BackendlessDataQuery query )
  {
    return Backendless.Data.of(KeyWordOriginalBK.class ).find( query );
  }

  public static Future<BackendlessCollection<KeyWordOriginalBK>> findAsync( BackendlessDataQuery query )
  {
    if( Backendless.isAndroid() )
    {
      throw new UnsupportedOperationException( "Using this method is restricted in Android" );
    }
    else
    {
      Future<BackendlessCollection<KeyWordOriginalBK>> future = new Future<BackendlessCollection<KeyWordOriginalBK>>();
      Backendless.Data.of(KeyWordOriginalBK.class ).find( query, future );

      return future;
    }
  }

  public static void findAsync( BackendlessDataQuery query, AsyncCallback<BackendlessCollection<KeyWordOriginalBK>> callback )
  {
    Backendless.Data.of(KeyWordOriginalBK.class ).find( query, callback );
  }
}