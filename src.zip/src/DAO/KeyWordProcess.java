/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import BE.KeyWordOriginal;
import com.backendless.persistence.BackendlessDataQuery;
import common.Constants;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author hoabt2
 */
public class KeyWordProcess {

    static int indexUrlKey = 0;

    static String getUrlKey() {
        return Constants.arrUrlKey[(indexUrlKey++) % Constants.arrUrlKey.length];
    }

    static boolean addUniqueKey(String key) {
        return addUniqueKey(key, 0, null);
    }

    static boolean addUniqueKey(String key, int status, String description) {
        boolean result = false;
        try {
            KeyWordOriginal kwo = new KeyWordOriginal();
            kwo.setKey(key);
            KeyWordOriginal tmp = kwo.save();
            if (tmp.getKey().equals(key)) {
                result = true;
            }
        } catch (Exception e) {
            result = false;
        }
        return result;
    }

    public static List<String> uniqueKey(List<String> lstKey) {
        List<String> lstResults = new ArrayList<>();
        for (String key : lstKey) {
            if (addUniqueKey(key)) {
                lstResults.add(key);
            }
        }
        return lstResults;
    }

    public static List<String> uniqueKeySuggest(List<String> lstKey, String description) {
        List<String> lstResults = new ArrayList<>();
        for (String key : lstKey) {
            if (addUniqueKey(key, 1, description)) {
                lstResults.add(key);
            }
        }
        return lstResults;
    }

    public static List<String> getSuggestKey(String key, String language, String country) {
        List<String> lstResults = new ArrayList<>();
        try {
            Document doc = Jsoup.connect(getUrlKey()).
                    userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0").
                    data("key", key, "language", language, "country", country).post();
            String[] arrTmp = doc.text().split("@,@");
            lstResults.addAll(Arrays.asList(arrTmp));
        } catch (IOException ex) {
            Logger.getLogger(KeyWordProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lstResults;
    }
}
