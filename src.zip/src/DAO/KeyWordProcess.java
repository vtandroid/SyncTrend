/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import BE.KeyWordOriginal;
import com.backendless.persistence.BackendlessDataQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hoabt2
 */
public class KeyWordProcess {

    static boolean addUniqueKey(String key) {
        boolean result = false;
        try {
            KeyWordOriginal kwo = new KeyWordOriginal();
            kwo.setKey(key);
            KeyWordOriginal tmp = kwo.save();
            if (tmp.getKey().equals(key)) {
                result = true;
            }
        } catch (Exception e) {
            result = false;
        }
        return result;
    }

    public static List<String> uniqueKey(List<String> lstKey) {
        List<String> lstResults = new ArrayList<>();
        for (String key : lstKey) {
            if (addUniqueKey(key)) {
                lstResults.add(key);
            }
        }
        return lstResults;
    }
}
