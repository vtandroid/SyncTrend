/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import BE.ConfigResource;
import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.persistence.BackendlessDataQuery;
import common.Constants;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author hoabt2
 */
public class ResourceHelper extends Thread {

    static HashMap<String, String> hashResource = new HashMap<>();

    static {
        Backendless.initApp(Constants.APPLICATION_ID, Constants.SECRET_KEY, Constants.VERSION);
        sync();
        new ResourceHelper().start();
    }

    static void sync() {
        BackendlessDataQuery backendlessDataQuery = new BackendlessDataQuery();
        BackendlessCollection<ConfigResource> collectionSystemConfig = ConfigResource.find(backendlessDataQuery);
        do {
            List<ConfigResource> lstSC = collectionSystemConfig.getCurrentPage();
            for (ConfigResource item : lstSC) {
                hashResource.put(item.getKey(), item.getValue());
            }
            collectionSystemConfig = collectionSystemConfig.nextPage();
        } while (collectionSystemConfig.getCurrentPage().size() > 0);
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(60000);
                sync();
            } catch (Exception ex) {

            }
        }
    }

    public static String getValue(String key) {
        return hashResource.get(key);
    }
}
