/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import BE.ConfigResource;
import BE.KeyWordOriginal;
import BE.KeyWordOriginalBK;
import static DAO.ResourceHelper.sync;
import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.persistence.BackendlessDataQuery;
import com.backendless.persistence.QueryOptions;
import common.Constants;
import java.util.List;

/**
 *
 * @author hoabt2
 */
public class KeyWordBackUpProcess extends Thread {

    static {
        Backendless.initApp(Constants.APPLICATION_ID, Constants.SECRET_KEY, Constants.VERSION);
    }

    static KeyWordOriginalBK getBackUpObject(KeyWordOriginal o) {
        KeyWordOriginalBK tmp = new KeyWordOriginalBK();
        tmp.setKey(o.getKey());
        tmp.setStatus(o.getStatus());
        tmp.setDescription(o.getDescription());
        return tmp;
    }

    static void backup() {
        int releaseKeyWord = Integer.parseInt(ResourceHelper.getValue("RELEASE_KEYWORD_NUMBER"));
        int maxKeyWordOriginal = Integer.parseInt(ResourceHelper.getValue("MAX_KEYWORD_ORIGINAL"));
        QueryOptions queryOptions = new QueryOptions("created");
        BackendlessDataQuery backendlessDataQuery = new BackendlessDataQuery(queryOptions);
        BackendlessCollection<KeyWordOriginal> collectionKeyWordOriginal = KeyWordOriginal.find(backendlessDataQuery);
        if (collectionKeyWordOriginal.getTotalObjects() > maxKeyWordOriginal) {
            List<KeyWordOriginal> lstTmp;
            KeyWordOriginal tmpKWO;
            int countKeyWordBK = 0;
            do {
                lstTmp = collectionKeyWordOriginal.getCurrentPage();
                for (int i = 0; i < lstTmp.size(); i++) {
                    tmpKWO = lstTmp.get(i);
                    getBackUpObject(tmpKWO).save();
                    tmpKWO.remove();
                    countKeyWordBK++;
                }
            } while (lstTmp.size() > 0 && countKeyWordBK < releaseKeyWord);
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(60000);
                backup();
            } catch (Exception ex) {

            }
        }
    }

}
