/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

/**
 *
 * @author hoabt2
 */
public class Constants {
    
    public static final String APPLICATION_ID = "191A60B8-18D2-8105-FFA4-9D8126B62400";
    public static final String SECRET_KEY = "C6DCF7B3-52A6-56B0-FF99-9128942E7B00";
    public static final String VERSION = "v1";
}
