/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.kafka.consumer.hikaridemo.common;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hoabt2
 */
public class KeyHelper {

    public static List<String> uniqueKeySQL(List<String> lstKey, int status, String des) {
        Connection connection = null;
        Statement statement = null;
        List<String> lstResult = new ArrayList<>();
        try {
            connection = DatabaseConnectionPool.getConnection();
            statement = connection.createStatement();
            StringBuilder sb;
            for (String key : lstKey) {
                try {
                    sb = new StringBuilder("INSERT INTO QOS2(KEYQ,STATUS,DESCRIPTION) VALUES('");
                    sb.append(key);
                    sb.append("',");
                    sb.append(status);
                    sb.append(",'");
                    sb.append(des);
                    sb.append("')");
                    statement.execute(sb.toString());
                    lstResult.add(key);
                } catch (SQLException sQLException) {
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(KeyHelper.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            DatabaseConnectionPool.close(statement);
            DatabaseConnectionPool.close(connection);
        }
        return lstResult;
    }
}
