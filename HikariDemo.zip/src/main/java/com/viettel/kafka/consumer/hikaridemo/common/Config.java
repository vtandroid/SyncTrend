/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.kafka.consumer.hikaridemo.common;

/**
 *
 * @author hoabt2
 */
public class Config {

    public static String JDBC_URL = "jdbc:mysql://localhost:3306/test";
    public static String USER_NAME_DB = "root";
    public static String PASS_WORD_DB = "";

}
